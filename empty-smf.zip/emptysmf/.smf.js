var fs = require('fs');
var xml2js = require('xml2js');
var _ = require("lodash");

var parser = new xml2js.Parser();

function respond(msg){
    process.stdout.write(JSON.stringify(msg));
}

fs.readFile(__dirname + '/builds/android/PackageProfiles.xml', function(err, data) {
    if(err){
        return respond({"error": "PackageProfiles.xml file was not found." });
    }
    parser.parseString(data, function (err, result) {
        if(err){
            return respond({"error": "PackageProfiles.xml is not correctly formatted." });
        }
        //console.log(JSON.stringify(result, null, 2));
        var profiles = _.map(result.packageProfiles.profile, function(profile){
            return profile.$.Name;
        });
        respond({"profiles": profiles });
    });
});


var config = require('./config-serkan.json');
